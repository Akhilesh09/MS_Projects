﻿// =============================================================================
// VIZA654/CSCE646 at Texas A&M University
// Homework 0
// Created by Anton Agana based from Ariel Chisholm's template
// 05.23.2011
//
// This file is supplied with an associated makefile. Put both files in the same
// directory, navigate to that directory from the Linux shell, and type 'make'.
// This will create a program called 'pr01' that you can run by entering
// 'homework0' as a command in the shell.
//
// If you are new to programming in Linux, there is an
// excellent introduction to makefile structure and the gcc compiler here:
//
// http://www.cs.txstate.edu/labs/tutorials/tut_docs/Linux_Prog_Environment.pdf
//
// =============================================================================

#include <cstdlib>
#include <iostream>
#include <GL/glut.h>


#include <fstream>
#include <cassert>
#include <sstream>
#include <string>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#include <stb_image_write.h>
#include <string>

using namespace std;

// =============================================================================
// These variables will store the input ppm image's width, height, and color
// =============================================================================
//int width, height;
unsigned char *pixmap1;
unsigned char *image1;

unsigned char *pixmap2;
unsigned char *image2;

unsigned char *pixmap3;
unsigned char *image3;

double *pixmap4;
unsigned char *pixmap5;

int width = 300, height = 300, channels1, channels2, channels3;


// =============================================================================
// setPixels()
//
// This function stores the RGB values of each pixel to "pixmap."
// Then, "glutDisplayFunc" below will use pixmap to display the pixel colors.
// =============================================================================
void setPixels()
{

	stbi_set_flip_vertically_on_load(false);
	image1 = stbi_load("dark.jpg", &width, &height, &channels1, STBI_rgb);
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int i = (y * width + x) * 3;
			pixmap1[i] = image1[i++];
			pixmap1[i] = image1[i++];
			pixmap1[i] = image1[i++];
		}
	}

	image2 = stbi_load("light.jpg", &width, &height, &channels2, STBI_rgb);
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int i = (y * width + x) * 3;
			pixmap2[i] = image2[i++];
			pixmap2[i] = image2[i++];
			pixmap2[i] = image2[i++];
		}
	}

	image3 = stbi_load("normal.jpg", &width, &height, &channels3, STBI_rgb);
	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int i = (y * width + x) * 3;
			pixmap3[i] = image3[i++];
			pixmap3[i] = image3[i++];
			pixmap3[i] = image3[i++];
		}
	}

	for (int y = 0; y < height; y++) {
		for (int x = 0; x < width; x++) {
			int i = (y * width + x) * 3;
			pixmap4[i] = (double)(2 * pixmap3[i] / 255.0 - 1);
			i++;
			pixmap4[i] = (double)(2 * pixmap3[i] / 255.0 - 1);
			i++;
			pixmap4[i] = (double)(2 * pixmap3[i] / 255.0 - 1);
			i++;
		}
	}

	double lx[100], ly[100], lz[100];


	for (int i = 0; i < 100; i++)
	{
		lx[i] = sin(i * 5);
		ly[i] = cos(i * 5);
	}

	for (int l = 0; l < 100; l++)
	{
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				int i = (y * width + x) * 3;
				double Tx = 0.5*(pixmap4[i] * lx[l]) + 0.5;
				pixmap5[i] = pixmap1[i] * (1 - Tx) + pixmap2[i] * Tx;
				i++;
				double Ty = 0.5*(pixmap4[i] * ly[l]) + 0.5;
				pixmap5[i] = pixmap1[i] * (1 - Ty) + pixmap2[i] * Ty;
				i++;
				double Tz = 0.5*(pixmap4[i] * 0) + 0.5;
				pixmap5[i] = pixmap1[i] * (1 - Tz) + pixmap2[i] * Tz;
				i++;
			}
		}

		string filename1 = "output/h" + to_string(l) + ".jpg";
		stbi_write_jpg(filename1.c_str(), 300, 300, channels1, pixmap5, 100);
	}
}


// =============================================================================
// OpenGL Display and Mouse Processing Functions.
//
// You can read up on OpenGL and modify these functions, as well as the commands
// in main(), to perform more sophisticated display or GUI behavior. This code
// will service the bare minimum display needs for most assignments.
// =============================================================================
static void windowResize(int w, int h)
{
	glViewport(0, 0, w, h);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, (w / 2), 0, (h / 2), 0, 1);
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
}
static void windowDisplay(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glRasterPos2i(0, 0);
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glDrawPixels(width, height, GL_RGB, GL_UNSIGNED_BYTE, pixmap5);
	glFlush();
}
static void processMouse(int button, int state, int x, int y)
{
	if (state == GLUT_UP)
		exit(0);               // Exit on mouse click.
}
static void init(void)
{
	glClearColor(1, 1, 1, 1); // Set background color.
}

// =============================================================================
// main() Program Entry
// =============================================================================
int main(int argc, char *argv[])
{

	//initialize the global variables
	width = 300;
	height = 300;
	pixmap1 = new unsigned char[300 * 300 * 3];
	pixmap2 = new unsigned char[300 * 300 * 3];
	pixmap3 = new unsigned char[300 * 300 * 3];
	pixmap4 = new double[300 * 300 * 3];
	pixmap5 = new unsigned char[300 * 300 * 3];

	setPixels();


	// OpenGL Commands:
	// Once "glutMainLoop" is executed, the program loops indefinitely to all
	// glut functions.  
	glutInit(&argc, argv);
	glutInitWindowPosition(100, 100); // Where the window will display on-screen.
	glutInitWindowSize(width, height);
	glutInitDisplayMode(GLUT_RGB | GLUT_SINGLE);
	glutCreateWindow("Homework Zero");
	init();
	glutReshapeFunc(windowResize);
	glutDisplayFunc(windowDisplay);
	glutMouseFunc(processMouse);
	glutMainLoop();

	return 0; //This line never gets reached. We use it because "main" is type int.
}